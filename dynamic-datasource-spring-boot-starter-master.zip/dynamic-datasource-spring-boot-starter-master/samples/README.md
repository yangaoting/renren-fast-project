# 演示例子

所有数据库连接为h2数据库，仅供测试。

所有测试可直接跑，注意启动的日志。

1. dynamic-jdbc-template-sample 原生jdbcTemplate下使用的示范
2. dynamic-mybatis-sample 原生mybatis下使用的示范
3. dynamic-mybatisplus2-sample mybatisPlus2下使用的示范
4. dynamic-mybatisplus3-sample mybatisPlus3下使用的示范
5. dynamic-druid-mybatis-sample mybatis和druid下使用的示范
6. dynamic-spel-sample mybatis和从参数获取数据源下使用的示范（高级）适用于多租户
7. dynamic-nest-sample 嵌套切换示范