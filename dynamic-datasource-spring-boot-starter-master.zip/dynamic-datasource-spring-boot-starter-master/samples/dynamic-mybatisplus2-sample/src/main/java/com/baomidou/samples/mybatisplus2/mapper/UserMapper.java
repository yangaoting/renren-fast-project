package com.baomidou.samples.mybatisplus2.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.samples.mybatisplus2.entity.User;

public interface UserMapper extends BaseMapper<User> {

}
